package com.demo.flight_reservation_app1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.flight_reservation_app1.entity.ListHotel;

public interface ListHotelRepository extends JpaRepository<ListHotel, Long> {

}
